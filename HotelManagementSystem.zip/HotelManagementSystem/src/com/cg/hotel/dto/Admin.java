package com.cg.hotel.dto;

public class Admin {
	private int id;
private String name; 
private String password;
 private String code;
 private String username;
 private String mobileNo;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
@Override
public String toString() {
	return "Admin [id=" + id + ", name=" + name + ", password=" + password
			+ ", code=" + code + ", username=" + username + ", mobileNo="
			+ mobileNo + "]";
}
public Admin(int id, String name, String password, String code,
		String username, String mobileNo) {
	super();
	this.id = id;
	this.name = name;
	this.password = password;
	this.code = code;
	this.username = username;
	this.mobileNo = mobileNo;
}
public Admin() {
	// TODO Auto-generated constructor stub
}

 
}
 
