package com.cg.hotel.dto;

public class Hotel {
 private int id;
 private int availableRooms;
 private  String roomType;
 private Boolean availability ;
 
 
 public Hotel(){}


public Hotel(int id, int availableRooms, String roomType,
		Boolean availability) {
	super();
	this.id = id;
	this.availableRooms = availableRooms;
	this.roomType = roomType;
	this.availability = availability;
}


public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public int getAvailableRooms() {
	return availableRooms;
}


public void setAvailableRooms(int availableRooms) {
	this.availableRooms = availableRooms;
}


public String getRoomType() {
	return roomType;
}


public void setRoomType(String roomType) {
	this.roomType = roomType;
}


public Boolean getAvailability() {
	return availability;
}


public void setAvailability(Boolean availability) {
	this.availability = availability;
}


@Override
public String toString() {
	return "Hotel [id=" + id + ", availableRooms=" + availableRooms
			+ ", roomType=" + roomType + ", availability=" + availability + "]";
}
 
 
 
}


