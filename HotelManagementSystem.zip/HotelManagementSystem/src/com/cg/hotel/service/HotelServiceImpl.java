package com.cg.hotel.service;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.hotel.dao.HotelDao;
import com.cg.hotel.dao.HotelDaoImpl;
import com.cg.hotel.dto.Admin;
import com.cg.hotel.dto.Customer;
import com.cg.hotel.dto.Hotel;
import com.cg.hotel.exception.HotelException;



public class HotelServiceImpl implements HotelService {
	static HotelService service = new HotelServiceImpl();
	static Scanner sc = null;
	static Customer customer = null;
	static Admin account = null;
	static int choice;
	static String add;

	HotelDao dao;
	
	public void setDao(HotelDao dao)
	{
		this.dao = dao;
	}
	
	public HotelServiceImpl()
	{
		dao = (HotelDao) new HotelDaoImpl();
	}

	
	public int addAdmin(Admin emp) throws HotelException {
		// TODO Auto-generated method stub
		return dao.addAdmin(emp);
	}

	public Admin getAdminById(int empId) throws HotelException {
		// TODO Auto-generated method stub
		return dao.getAdminById(empId);
	}

	public int addCustomer(Customer emp) throws HotelException {
		// TODO Auto-generated method stub
		return dao.addCustomer(emp);
	}

	

	public Customer getCustomerById(int empId) throws HotelException {
		// TODO Auto-generated method stub
		return dao.getCustomerById(empId);
	}
	public ArrayList<Admin> getAllAdmin() throws HotelException {
		// TODO Auto-generated method stub
		return dao.getAllAdmin();
	}
	
	public ArrayList<Customer> getAllCustomer() throws HotelException {
		// TODO Auto-generated method stub
		return dao.getAllCustomer();
	}
	public boolean validateName(String name)
	{
		String pattern = "[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,name))
		{
			return true;
		}
		else
		{ System.out.println("password should be string.");
			return false;
	}}
	public boolean validatePhone(String mobile)
	{
		String pattern = "[0-9]{10}";
		String phone = ""+mobile;
		if(Pattern.matches(pattern,phone))
		{
			return true;
		}
		else 
		{System.out.println("Mobile number should be of 10 digits");
			return false;
	}}

	
	public Hotel getRoomInfo(int id) throws HotelException {
		// TODO Auto-generated method stub
		return dao.getRoomInfo(id);
	}

	

	

	
}
