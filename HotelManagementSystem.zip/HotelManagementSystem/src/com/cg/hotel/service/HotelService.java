package com.cg.hotel.service;

import java.util.ArrayList;

import com.cg.hotel.dto.Admin;
import com.cg.hotel.dto.Customer;
import com.cg.hotel.dto.Hotel;
import com.cg.hotel.exception.HotelException;

public interface HotelService {
	int addAdmin(Admin emp)throws HotelException;
	int addCustomer(Customer emp)throws HotelException;
	Admin getAdminById(int empId)throws HotelException;
	Customer getCustomerById(int empId)throws HotelException;
	boolean validateName(String name);
	boolean validatePhone(String mobile);
	ArrayList<Admin>getAllAdmin()throws HotelException;
	ArrayList<Customer>getAllCustomer()throws HotelException;
	Hotel getRoomInfo(int id)throws HotelException;
	Customer removeCustomer(int custId)throws HotelException;
}
