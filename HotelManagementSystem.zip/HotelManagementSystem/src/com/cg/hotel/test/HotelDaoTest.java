package com.cg.hotel.test;



import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.hotel.dao.HotelDao;
import com.cg.hotel.dao.HotelDaoImpl;
import com.cg.hotel.dto.Admin;
import com.cg.hotel.exception.HotelException;
import com.cg.hotel.service.HotelServiceImpl;


public class HotelDaoTest {
	HotelServiceImpl service;
	HotelDao dao;
	
	@Before
	public void init()
	{
		dao = new HotelDaoImpl();
		service  = new HotelServiceImpl();
		service.setDao(dao);
	}
	
	@Test
	public void testAddAdmin() throws HotelException
	{
		Admin emp = new Admin();
		emp.setId(1);
		emp.setName("Shilpa");
		emp.setUsername("shilpamandke");
		emp.setMobileNo("7890785643");
		emp.setPassword("shilpa");
		emp.setCode("123456");
		
		int id = service.addAdmin(emp);
		assertNotSame(id,0);
	}
	
	@After
	public void destroy()
	{
		dao = null;
		service = null;
	}

}
