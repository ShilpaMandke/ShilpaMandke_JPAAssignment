package com.cg.hotel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import com.cg.hotel.dto.Admin;
import com.cg.hotel.dto.Customer;
import com.cg.hotel.dto.Hotel;
import com.cg.hotel.exception.HotelException;
import com.cg.hotel.logger.MyLogger;
import com.cg.hotel.util.DBUtil;



public class HotelDaoImpl implements HotelDao {

	Connection con;
	Logger logger;
	
	
	public HotelDaoImpl()
	{
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}

	public int getAdminId()throws HotelException
	{
		logger.info("In getAdminId");
		int id = 0;
		String qry = "SELECT adminId_seq.CURRVAL FROM DUAL";
			try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id = rs.getInt(1);
				logger.info("Got Admin User With Id"+id);
			}
			}
			catch(SQLException e)
			{
				logger.error("Error"+e.getMessage());
				throw new HotelException(e.getMessage());
			}
			logger.info("Completed getAdminId");
			return id;
		
	}

	public int getCustomerId()throws HotelException
	{
		logger.info("In getCustomerId");
		int id1 = 0;
		String qry = "SELECT custId_seq.CURRVAL FROM DUAL";
			try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id1 = rs.getInt(1);
				logger.info("Got  Customer With Id number"+id1);
			}
			}
			catch(SQLException e)
			{
				logger.error("Error"+e.getMessage());
				throw new HotelException(e.getMessage());
			}
			logger.info("Completed getCustomerId");
			return id1;
		
	}
	public int addAdmin(Admin emp) throws HotelException {
		// TODO Auto-generated method stub
		logger.info("In Add Admin");
		logger.info("Input is "+emp);
		int id = 0;
		String qry = "INSERT INTO Admin VALUES(adminId_seq.NEXTVAL,?,?,?,?,?)";
		String name = emp.getName();
		String username = emp.getUsername();
		String password = emp.getPassword();
		String mobile = emp.getMobileNo();
		String spcode = emp.getCode();
		
		
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setString(1, name);
			pstmt.setString(2, username);
			pstmt.setString(3, password);
			pstmt.setString(4, mobile);
			pstmt.setString(5, spcode);
			
			
			
			
			
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id = getAdminId();
				logger.info("Inserted successfully and Id is = "+id);
			}
			else
				throw new HotelException("unable to insert"+emp);
			
		}
		catch(SQLException e)
		{
			logger.error("Error in insert = "+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		return id;
		
		
		
		
		
	}

	
	public Admin getAdminById(int adminId) throws HotelException {
		// TODO Auto-generated method stub
		Admin emp = null;
		String qry = "SELECT * FROM Admin WHERE adminId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, adminId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String username = rs.getString(3);
				String password = rs.getString(4);
				String mobile = rs.getString(5);
				String spcode = rs.getString(6);




				emp = new Admin(id,name,username,password,mobile,spcode);
			}
			else
				throw new HotelException("Admin with id "+adminId+"not found");
		}
		catch(SQLException e)
		{
			throw new HotelException(e.getMessage());
		}
		return emp;
	}

	public int addCustomer(Customer emp) throws HotelException {
		// TODO Auto-generated method stub
		logger.info("In Add Customer");
		logger.info("Input is "+emp);
		int id1 = 0;
		String qry = "INSERT INTO customer VALUES(custId_seq.NEXTVAL,?,?,?,?,?,?,?)";
		String name = emp.getName();
		String username = emp.getUsername();
		String password = emp.getPassword();
		String phone = emp.getPhoneNo1();
		String address = emp.getAddress();
		String city = emp.getCity();
		String email = emp.getEmail();
		
		
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setString(1, name);
			pstmt.setString(2, username);
			pstmt.setString(3, password);
			pstmt.setString(4, phone);
			pstmt.setString(5, address);
			pstmt.setString(6, city);
			pstmt.setString(7, email);
			
			
			
			
			
			
			
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id1 = getCustomerId();
				logger.info("Inserted successfully and Id Number  is = "+id1);
			}
			else
				throw new HotelException("unable to insert"+emp);
			
		}
		catch(SQLException e)
		{
			logger.error("Error in insert = "+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		return id1;
		
		
		
		
		
	}


	public Customer getCustomerById(int custId) throws HotelException {
		// TODO Auto-generated method stub
		Customer emp = null;
		String qry = "SELECT * FROM customer WHERE custId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, custId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String username = rs.getString(3);
				String password = rs.getString(4);
				String mobile = rs.getString(5);
				String address = rs.getString(6);
				String city = rs.getString(7);
				String email = rs.getString(8);
				




				emp = new Customer(id,name,username,password,mobile,address,city,email);
			}
			else
				throw new HotelException("User with id "+custId+"not found");
		}
		catch(SQLException e)
		{
			throw new HotelException(e.getMessage());
		}
		return emp;
	}
	
	public ArrayList<Admin> getAllAdmin() throws HotelException {
		// TODO Auto-generated method stub
		ArrayList<Admin>list = new ArrayList<Admin>();
		String qry = "SELECT * FROM Admin";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String username=rs.getString(3);
				String password=rs.getString(4);
				String mobile= rs.getString(5);
				String spcode=rs.getString(6);
				
				Admin emp = new Admin(id,name,username,password,mobile,spcode);
				list.add(emp);
			}
		}
		catch(SQLException e)
		{
			throw new HotelException(e.getMessage());
		}
		return list;
	}
	
	public ArrayList<Customer> getAllCustomer() throws HotelException {
		// TODO Auto-generated method stub
		ArrayList<Customer> list = new ArrayList<Customer>();
		String qry = "SELECT * FROM customer";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String username=rs.getString(3);
				String password=rs.getString(4);
				String mobile= rs.getString(5);
				String address=rs.getString(6);
				String city=rs.getString(7);
				String email=rs.getString(8);
				
				Customer emp = new Customer(id,name,username,password,mobile,address,city,email);
				list.add(emp);
			}
		}
		catch(SQLException e)
		{
			throw new HotelException(e.getMessage());
		}
		return list;
	}

	public Hotel getRoomInfo(int  id) throws HotelException {
		// TODO Auto-generated method stub
		Hotel emp = null;
		String qry = "SELECT * FROM hotel WHERE hotelId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int hotelId = rs.getInt(1);
				int rooms = rs.getInt(2);
				String type = rs.getString(3);
				Boolean roomavail = rs.getBoolean(4);
				
			   emp = new Hotel(hotelId,rooms,type,roomavail);
			}
			else
				throw new HotelException("Room with id "+id+"not found");
		}
		catch(SQLException e)
		{
			throw new HotelException(e.getMessage());
		}
		return emp;
	}
	
	
	public Customer removeCustomer(int custId) throws HotelException {
		// TODO Auto-generated method stub
		Customer emp = null;
		String qry = "DELETE FROM customer WHERE custId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, custId);
			emp = getCustomerById(custId);
			int row = pstmt.executeUpdate();
			if(emp==null)
			{
				throw new HotelException("emp with id "+custId+"not found");
			}
			else if(row > 0)
			{
				System.out.println("Deleted Employee with Id "+custId);
				
			}
			
		}
		catch(SQLException e)
		{
			throw new HotelException(e.getMessage());
		}
		return emp;
	}
	
	}


