package com.cg.hotel.dao;


import java.util.ArrayList;


import com.cg.hotel.dto.Admin;
import com.cg.hotel.dto.Customer;
import com.cg.hotel.dto.Hotel;
import com.cg.hotel.exception.HotelException;

public interface HotelDao {
	int addAdmin(Admin admin)throws HotelException;
	int addCustomer(Customer cust)throws HotelException;
	Hotel getRoomInfo(int id)throws HotelException;
	
	Admin getAdminById(int adminId)throws HotelException;
	ArrayList<Admin>getAllAdmin()throws HotelException;
	ArrayList<Customer>getAllCustomer()throws HotelException;
	Customer removeCustomer(int custId)throws HotelException;
	Customer getCustomerById(int custId)throws HotelException;
}
