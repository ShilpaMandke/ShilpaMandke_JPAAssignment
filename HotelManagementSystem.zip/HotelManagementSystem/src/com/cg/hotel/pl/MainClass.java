package com.cg.hotel.pl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.hotel.dto.Admin;
import com.cg.hotel.dto.Customer;
import com.cg.hotel.dto.Hotel;
import com.cg.hotel.exception.HotelException;
import com.cg.hotel.service.HotelService;
import com.cg.hotel.service.HotelServiceImpl;

public class MainClass {
	static Scanner sc = null;
	static Customer customer = null;
	static Admin account = null;
	static int choice;
	static String add;
	static HotelService service = new HotelServiceImpl();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sc = new Scanner(System.in);
		service = new HotelServiceImpl();
		try {
			menuDriven();
		} catch (HotelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
	}
		
	public static void menuDriven() throws HotelException, IOException
	{
		while(true)
		{
			System.out.println("------------------------*******************-----------------------------");
			System.out.println("------------------------J W Marriott-----------------------------");
			System.out.println("------------------------*******************-----------------------------");
			System.out.println("1: Register Account");
			System.out.println("2: Login");
			System.out.println("3: Exit");
			System.out.println("Enter choice::");
			
			choice = sc.nextInt();
			switch (choice) 
			{
			case 1:
				System.out.println("1-Register as a Admin");
				System.out.println("2-Register as a User");
				System.out.println("3- Exit");
				
				
				
				System.out.println("Enter choice::");
				choice = sc.nextInt();
						switch(choice) {
							case 1:
				
								Admin emp = acceptAdminDetails(); 
								if(emp!=null)
								{	
									try
									{
										int id = service.addAdmin(emp);
										System.out.println("admin has been inserted and id = "+id);
									}
									catch(HotelException e)
									{
										System.out.println(e.getMessage());
									}
								}
								break;
                            case 2:
								
								Customer emp1 = acceptCustomerDetails(); 
								if(emp1!=null)
								{	
									try
									{
										int id = service.addCustomer(emp1);
										System.out.println(" Customer has been inserted and id = "+id);
									}
									catch(HotelException e)
									{
										System.out.println(e.getMessage());
									}
								}
								break;
								
                        	case 3:
            					System.out.println("THANK YOU FOR USING OUR SERVICES! PLEASE VISIT AGAIN");
            					System.exit(0);
            					
            				default:
            					System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
            					break;
            			
            				}
			case 2:
				System.out.println("1-Login as a Admin");
				System.out.println("2-Login as a User");
				System.out.println("3- Exit");
				
				
				
				System.out.println("Enter choice::");
				choice = sc.nextInt();
						switch(choice) 
				{
						case 1:adminLogin();
						break;
						case 2:customerLogin();
						break;
						case 3:
							System.out.println("THANK YOU FOR USING OUR SERVICES! PLEASE VISIT AGAIN");
							System.exit(0);
						default:
							System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
							break;
				}
				
				break;	
		
				
			case 3:
				System.out.println("THANK YOU FOR USING OUR SERVICES! PLEASE VISIT AGAIN");
				System.exit(0);

			default:
				System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
				break;
			}


		}

	}
					
	private static void adminLogin() throws HotelException
	{
		String user_name;
		String password;
		System.out.println("WELCOME TO LOGIN OPTION OF J W Marriott In A ADMIN MODE");
		System.out.println("Enter the UserName:");
		user_name = sc.next();
		System.out.println("Enter the Password:");
		password = sc.next();
		
		ArrayList<Admin>list = 
				service.getAllAdmin();
				for(Admin obj : list)

				
				{}
		Iterator<Admin> it = list.iterator();
		while(it.hasNext())
		{
			account = it.next();
			String user = account.getUsername();
			String pw = account.getPassword();
			if(user.equals(user_name)&& pw.equals(password))
			{
				while(true)
				{

					System.out.println("\n------------------------");
					System.out.println("WELCOME TO J W Marriott");
					System.out.println("--------------------------\n");
					System.out.println("1: Add Customer ");
					System.out.println("2: Remove Customer");
					//System.out.println("3: Show Balance of customer");
					System.out.println("4: Update records of Customer");
					System.out.println("5: View customer records");
					System.out.println("6: LogOut");
					System.out.println(" Enter your choice:");
					choice = sc.nextInt();
					switch (choice) 
					{
					case 1:
						acceptCustomerDetails();
						break;
					case 2:
					//	removeUser();
						break;
					case 3:
						//showBal();
						break;
					case 4:
						//transfer();
						break;
					case 5:
						//printTransaction();
						break;
					case 6:
						//view();
						break;
					case 7:
						System.out.println("THANK YOU FOR CHOOSING OUR SERVICES!");
						try {
							menuDriven();
						} catch (HotelException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					default:
						System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
						break;
					}

				}
			}
		}
		
	}

	
	
	private static void customerLogin() throws HotelException
	{
		String user_name;
		String password;
		System.out.println("WELCOME TO LOGIN OPTION OF J W Marriott");
		System.out.println("Enter the UserName:");
		user_name = sc.next();
		System.out.println("Enter the Password:");
		password = sc.next();
		ArrayList<Customer>list = 
				service.getAllCustomer();
				for(Customer obj : list)
{
				System.out.println(obj);
}
				Iterator<Customer> it = list.iterator();
		while(it.hasNext())
		{
			customer = it.next();
			String user = customer.getUsername();
			String pw = customer.getPassword();
			if(user.equals(user_name)&& pw.equals(password))
			{
				while(true)
				{

					System.out.println("\n------------------------");
					System.out.println("WELCOME TO J W Marriott");
					System.out.println("--------------------------\n");
					//System.out.println("1: ");
					//System.out.println("2: Withdraw Money");
					System.out.println("1: Show available rooms of hotel");
					System.out.println("2: View all details of booking");
					//System.out.println("5: your interest calculator ");
					System.out.println("3: LogOut");
					System.out.println(" Enter your choice:");
					choice = sc.nextInt();
					switch (choice) 
					{
					case 1:System.out.println("Enter hotel ID:");
					int id = sc.nextInt();
					Hotel hotel=service.getRoomInfo(id);
					System.out.println("hotel:"+hotel);
						break;
					case 2:
						//withdraw();
						break;
					case 3:
						//showBal();
						break;
					
					case 4:
						//view();
						break;
					case 6:
						System.out.println("THANK YOU FOR CHOOSING OUR SERVICES!");
						try {
							menuDriven();
						} catch (HotelException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					default:
						System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
						break;
					}

				}
			}
			else
			{
				System.out.println("Invalid username or Password...");
			}
		}
		
	}

				
	public static Admin acceptAdminDetails()
	{
		Admin emp = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter name of Admin::");
			String name = sc.next();
			if(!service.validateName(name))
			{
				continue;
			}
			else
			{
				while(true)
				{
					System.out.println("Enter admin name to use in app:");
					String username = sc.next();
					if(!service.validateName(username))
					{
						continue;
					}
					else
					{
						System.out.println("Enter password of admin to use in app:");
						String password = sc.next();
						if(!service.validateName(password))
						{
							continue;
						}
						else
						{
							System.out.println("Enter Mobile number of admin :");
							String mobile = sc.next();
							if(!service.validatePhone(mobile))
							{
								continue;
							}
							else
							{
								System.out.println("Enter address of admin :");
								String spcode = sc.next();
								
						
						if(spcode!=null)
						{
							emp = new Admin();
							emp.setName(name);
							emp.setUsername(username);
							emp.setPassword(password);
							emp.setMobileNo(mobile);
							emp.setCode(spcode);
							
									break;
								}
							}
						}
					}
			
				break;}
		
			}
		return emp;

		}
	
	
	}
	public static Customer acceptCustomerDetails()
	{
		Customer emp = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter name of  Customer::");
			String name = sc.next();
			if(!service.validateName(name))
			{
				continue;
			}
			else
			{
				while(true)
				{
					System.out.println("Enter  username to use in app:");
					String username = sc.next();
					if(!service.validateName(username))
					{
						continue;
					}
					else
					{
						System.out.println("Enter password to use in app:");
						String password = sc.next();
						if(!service.validateName(password))
						{
							continue;
						}
						else
						{
							System.out.println("Enter Mobile number of Customer :");
							String phoneNo1 = sc.next();
							if(!service.validatePhone(phoneNo1))
							{
								continue;
							}
							else
							{
								System.out.println("Enter City of Customer :");
								String city = sc.next();
							
								
							
							
								System.out.println("Enter Email of Customer :");
									String email = sc.next();
								
									
							
								System.out.println("Enter address of Customer  :");
								String address = sc.next();
								
						
						if(address!=null)
						{
							emp = new Customer();
							emp.setName(name);
							emp.setUsername(username);
							emp.setPassword(password);
							emp.setPhoneNo1(phoneNo1);
							emp.setAddress(address);
							
							emp.setCity(city);
							emp.setEmail(email);
							
							
							
							break;
								}
							}
						}
					}
			
				}
		
			}
		return emp;

		}
	
	
	}
		}
	
	
			
				
			

