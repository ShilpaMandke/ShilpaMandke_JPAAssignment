package com.cg.bankingservice.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.bankingservice.dao.BankDao;
import com.cg.bankingservice.dao.BankDaoImpl;
import com.cg.bankingservice.dto.AdminRegister;
import com.cg.bankingservice.dto.UserRegister;
import com.cg.bankingservice.exception.BankException;



public class BankServiceImpl implements BankService
{
	BankDao dao;
	
	public void setDao(BankDao dao)
	{
		this.dao = dao;
	}
	
	public BankServiceImpl()
	{
		dao = new BankDaoImpl();
	}

	public int addAdmin(AdminRegister emp) throws BankException {
		// TODO Auto-generated method stub
		return dao.addAdmin(emp);
	}

	
	
	public AdminRegister getAdminById(int empId) throws BankException {
		// TODO Auto-generated method stub
		return dao.getAdminById(empId);
	}
	
	public ArrayList<AdminRegister> getAllAdmin() throws BankException {
		// TODO Auto-generated method stub
		return dao.getAllAdmin();
	}
	

	public int addUser(UserRegister emp) throws BankException {
		// TODO Auto-generated method stub
		return dao.addUser(emp);
	}

	
	public UserRegister getUserById(int empId) throws BankException {
		// TODO Auto-generated method stub
		return dao.getUserById(empId);
	}
	
	
	public ArrayList<UserRegister> getAllUser() throws BankException {
		// TODO Auto-generated method stub
		return dao.getAllUser();
	}
	
	public UserRegister updateUser(int empId, String name)
			throws BankException {
		// TODO Auto-generated method stub
		return dao.updateUser(empId, name);
	}

	
	

	public boolean validateName(String name)
	{
		String pattern = "[A-z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,name))
		{
			return true;
		}
		else
			return false;
	}
	public boolean validateSalary(int salary)
	{
		String pattern = "[0-9]{4,10}";
		String sal = ""+salary;
		if(Pattern.matches(pattern,sal))
		{
			return true;
		}
		else 
			return false;
	}
	public boolean validatePhone(int salary)
	{
		String pattern = "[0-9]{4,10}";
		String sal = ""+salary;
		if(Pattern.matches(pattern,sal))
		{
			return true;
		}
		else 
			return false;
	}
	
	
	public boolean validatePhone(String mobile) {
		// TODO Auto-generated method stub
		String pattern = "[0-9]{4,10}";
		String mob = ""+mobile;
		if(Pattern.matches(pattern,mob))
		{
			return true;
		}
		else 
			return false;
	}

	static BankService service = new BankServiceImpl();
	static Scanner sc = null;
	static UserRegister customer = null;
	static AdminRegister account = null;
	static int choice;
	static String add;


	
	

	
	public boolean validateSalary(double accountnumber) {
		// TODO Auto-generated method stub
		return false;
	}

	public UserRegister removeUser(int empId) throws BankException {
		// TODO Auto-generated method stub
		return dao.removeUser(empId);
	}

	public UserRegister updateAccountDeposit(int empId, Double amount)
			throws BankException {
		// TODO Auto-generated method stub
		return dao.updateAccountDeposit(empId, amount);
		
	}
	

	public UserRegister updateAccountWithdrwal(int empId, Double amount)
			throws BankException {
		// TODO Auto-generated method stub
		return dao.updateAccountWithdrawal(empId, amount);
	}


}




