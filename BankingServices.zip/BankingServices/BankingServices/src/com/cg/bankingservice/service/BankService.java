package com.cg.bankingservice.service;

import java.util.ArrayList;

import com.cg.bankingservice.dto.AdminRegister;
import com.cg.bankingservice.dto.UserRegister;
import com.cg.bankingservice.exception.BankException;


public interface BankService {

	int addAdmin(AdminRegister emp)throws BankException;
	AdminRegister getAdminById(int empId)throws BankException;
	
	int addUser(UserRegister emp)throws BankException;
	UserRegister getUserById(int empId)throws BankException;
	
	ArrayList<AdminRegister>getAllAdmin()throws BankException;
	ArrayList<UserRegister>getAllUser()throws BankException;
	
	UserRegister removeUser(int empId)throws BankException;

	UserRegister updateUser(int empId,String name)throws BankException;
	
	UserRegister updateAccountDeposit(int empId,Double amount)throws BankException;
	UserRegister updateAccountWithdrwal(int empId,Double amount)throws BankException;
	
	
	boolean validateSalary(double accountnumber);
	boolean validateName(String name);
	boolean validatePhone(String mobile);	
}
