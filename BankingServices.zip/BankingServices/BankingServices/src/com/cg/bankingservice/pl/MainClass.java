package com.cg.bankingservice.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.bankingservice.dto.AdminRegister;

import com.cg.bankingservice.dto.UserRegister;
import com.cg.bankingservice.exception.BankException;
import com.cg.bankingservice.service.BankService;
import com.cg.bankingservice.service.BankServiceImpl;




public class MainClass {
	static Scanner sc = null;
	static UserRegister customer = null;
	static AdminRegister account = null;
	static int choice;
	static String add;

	static BankService service = new BankServiceImpl();
	
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		service = new BankServiceImpl();
		try {
			menuDriven();
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
	}
		
	public static void menuDriven() throws BankException, IOException
	{
		while(true)
		{
			System.out.println("------------------------*******************-----------------------------");
			System.out.println("------------------------STATE BANK OF INDIA-----------------------------");
			System.out.println("------------------------*******************-----------------------------");
			System.out.println("1: Register Account");
			System.out.println("2: Login");
			System.out.println("3: Exit");
			choice = sc.nextInt();
			switch (choice) 
			{
			case 1:
				System.out.println("1-Register as a Admin");
				System.out.println("2-Register as a User");
				System.out.println("3- Exit");
				
				
				
				System.out.println("Enter choice::");
				choice = sc.nextInt();
						switch(choice) {
							case 1:
				
								AdminRegister emp = acceptAdminDetails(); 
								if(emp!=null)
								{	
									try
									{
										int id = service.addAdmin(emp);
										System.out.println("admmin user has been inserted and id = "+id);
									}
									catch(BankException e)
									{
										System.out.println(e.getMessage());
									}
								}
								break;
								
							case 2:
								
								UserRegister emp1 = acceptUserDetails(); 
								if(emp1!=null)
								{	
									try
									{
										int id = service.addUser(emp1);
										System.out.println(" user has been inserted and id = "+id);
									}
									catch(BankException e)
									{
										System.out.println(e.getMessage());
									}
								}
								break;
			
				case 3:
					System.out.println("THANK YOU FOR USING OUR SERVICES! PLEASE VISIT AGAIN");
					System.exit(0);
					
				default:
					System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
					break;
			
				}
				break;
			
			case 2:
				System.out.println("1-Login as a Admin");
				System.out.println("2-Login as a User");
				System.out.println("3- Exit");
				
				
				
				System.out.println("Enter choice::");
				choice = sc.nextInt();
						switch(choice) 
						{
						case 1:accountHolder();
						break;
						case 2:accountHolder1();
						break;
						case 3:
							System.out.println("THANK YOU FOR USING OUR SERVICES! PLEASE VISIT AGAIN");
							System.exit(0);
						default:
							System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
							break;
				
				
						}
			case 3:
				System.out.println("THANK YOU FOR USING OUR SERVICES! PLEASE VISIT AGAIN");
				System.exit(0);

			default:
				System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
				break;
			}


		}

	}

	private static void accountHolder() throws BankException
	{
		String user_name;
		String password;
		System.out.println("WELCOME TO LOGIN OPTION OF STATE BANK OF INDIA In A ADMIN MODE");
		System.out.println("Enter the UserName:");
		user_name = sc.next();
		System.out.println("Enter the Password:");
		password = sc.next();
		
		ArrayList<AdminRegister>list = 
				service.getAllAdmin();
				for(AdminRegister obj : list)

				
				{}
		Iterator<AdminRegister> it = list.iterator();
		while(it.hasNext())
		{
			account = it.next();
			String user = account.getAdminUserName();
			String pw = account.getPassword();
			
			if(user.equals(user_name)&& pw.equals(password))
			{
				while(true)
				{

					System.out.println("\n--------------------------");
					System.out.println("WELCOME TO STATE BANK OF INDIA");
					System.out.println("--------------------------\n");
					System.out.println("1: Add Customer ");
					System.out.println("2: Remove Customer");
					System.out.println("3: Show All details of account number");
					System.out.println("4: Update records of Customer");
					System.out.println("5: View all customer records ");
					System.out.println("6: LogOut");
					System.out.println(" Enter your choice:");
					choice = sc.nextInt();
					switch (choice) 
					{
					case 1:
						UserRegister emp = acceptUserDetails(); 
						if(emp!=null)
						{	
							try
							{
								int id = service.addUser(emp);
								System.out.println(" user has been inserted and account number = "+id);
							}
							catch(BankException e)
							{
								System.out.println(e.getMessage());
							}
						}
						break;
					case 2:
						System.out.println("Enter Account no to remove::");
						int id = sc.nextInt();
						try
						{
							UserRegister emp1 = service.removeUser(id);
							System.out.println("removed Customer "+emp1);
						}
						catch(BankException e)
						{
							System.out.println(e.getMessage());
						}
						break;
					case 3:
						System.out.println("Enter Account no to see Customer Account balance:");
						int eid = sc.nextInt();
						try
						{
							UserRegister ref = service.getUserById(eid);
							System.out.println("emp "+ref);
						}
						catch(BankException e)
						{
							System.out.println(e.getMessage());
						}
						break;
						
					case 4:
						System.out.println("By this facility you can update customer name and balance of particular account number :");
						
						
					System.out.println("Enter Account no to update record:");
					int empId = sc.nextInt(); 
					System.out.println("Enter Customer new name  to update  in record:");
					String  name = sc.next(); 
					
					try{
						UserRegister eObj = service.updateUser(empId, name);
						System.out.println("updated = "+eObj);
					}
					catch(BankException e)
					{
						System.out.println(e.getMessage());
					}
					break;
						
					case 5:
						try{ArrayList<UserRegister>list1 = 
						service.getAllUser();
						for(UserRegister obj : list1)
						{
							System.out.println(obj);
						}
						}
						catch(BankException e)
						{
							System.out.println(e.getMessage());
						}
						break;
					
					case 6:
						System.out.println("THANK YOU FOR CHOOSING OUR SERVICES!");
						try {
							menuDriven();
						} catch (BankException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					default:
						System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
						break;
					}

				}
			}
		}
		

	
	}

	
	private static void accountHolder1() throws BankException
	{
		String user_name;
		String password;
		System.out.println("WELCOME TO LOGIN OPTION OF STATE BANK OF INDIA");
		System.out.println("Enter the UserName:");
		user_name = sc.next();
		System.out.println("Enter the Password:");
		password = sc.next();
		ArrayList<UserRegister>list = 
				service.getAllUser();
				for(UserRegister obj : list)
				{
				System.out.println(obj);
				}
				Iterator<UserRegister> it = list.iterator();
		while(it.hasNext())
		{
			customer = it.next();
			String user = customer.getUserName();
			String pw = customer.getPassword();
			if(user.equals(user_name)&& pw.equals(password))
			{
				while(true)
				{

					System.out.println("\n------------------------");
					System.out.println("WELCOME TO STATE BANK OF INDIA");
					System.out.println("--------------------------\n");
					System.out.println("1: Deposit Money");
					System.out.println("2: Withdraw Money");
					System.out.println("3: Show balance of account");
					System.out.println("4: View all details of account");
					System.out.println("5: LogOut ");
					
					System.out.println(" Enter your choice:");
					choice = sc.nextInt();
					switch (choice) 
					{
					case 1:
						System.out.println("By this facility you can deposit amount in customer account number :");
						
						
						System.out.println("Enter Account no to deposit money:");
						int empId = sc.nextInt(); 
						System.out.println("Enter amount to deposit:");
						Double  amount = sc.nextDouble(); 
						
						try{
							UserRegister eObj = service.updateAccountDeposit(empId, amount);
							System.out.println("updated = "+eObj);
						}
						catch(BankException e)
						{
							System.out.println(e.getMessage());
						}
						break;
							
						
					case 2:
						System.out.println("By this facility you can withdrawl amount from customer account number :");
						
						
						System.out.println("Enter Account no to withdrawl  money from:");
						int empId1 = sc.nextInt(); 
						System.out.println("Enter amount to withdrawl:");
						Double  amount1 = sc.nextDouble(); 
						
						try{
							UserRegister eObj = service.updateAccountWithdrwal(empId1, amount1);
							System.out.println("updated = "+eObj);
						}
						catch(BankException e)
						{
							System.out.println(e.getMessage());
						}
						break;
						
					case 3:System.out.println("By this facility you can check your  bank account balance ");
					
					
					System.out.println("Enter Account no to see balance :");
					int empId2 = sc.nextInt(); 
					
					
					UserRegister eObj = service.getUserById(empId2);
					System.out.println("updated = "+eObj);
					break;
				
				
						
					
						
					case 4:
						System.out.println("By this facility you can check your All bank account ");
						
						
						System.out.println("Enter Account no to see balance :");
						int empId21 = sc.nextInt(); 
						
						
						UserRegister eObj1 = service.getUserById(empId21);
						System.out.println("updated = "+eObj1);
						break;
					
					
					
					case 5:
						System.out.println("THANK YOU FOR CHOOSING OUR SERVICES!");
						try {
							menuDriven();
						} catch (BankException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					default:
						System.out.println("INVALID CHOICE!"+"\n CHOOSE THE CORRECT OPTION");
						break;
					}

				}
			}
		}
		
	}


			
		
	
	public static AdminRegister acceptAdminDetails()
	{
		AdminRegister emp = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter name of admin user::");
			String name = sc.next();
			if(!service.validateName(name))
			{
				continue;
			}
			else
			{
				while(true)
				{
					System.out.println("Enter admin user name to use in app:");
					String username = sc.next();
					if(!service.validateName(username))
					{
						continue;
					}
					else
					{
						System.out.println("Enter password of admin to use in app:");
						String password = sc.next();
						if(!service.validateName(password))
						{
							continue;
						}
						else
						{
							System.out.println("Enter Mobile number of admin :");
							String mobile = sc.next();
							if(!service.validatePhone(mobile))
							{
								continue;
							}
							else
							{
								System.out.println("Enter address of admin :");
								String address = sc.next();
								
						
						if(address!=null)
						{
							emp = new AdminRegister();
							emp.setAdminName(name);
							emp.setAdminUserName(username);
							emp.setPassword(password);
							emp.setMobile(mobile);
							emp.setAddress(address);
							
									break;
								}
							}
						}
					}
			
				}
		
			}
		return emp;

		}
	
	
	}

	
	
	public static UserRegister acceptUserDetails()
	{
		UserRegister emp = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter name of  user::");
			String name = sc.next();
			if(!service.validateName(name))
			{
				continue;
			}
			else
			{
				while(true)
				{
					System.out.println("Enter  username of user  to use in app:");
					String username = sc.next();
					if(!service.validateName(username))
					{
						continue;
					}
					else
					{
						System.out.println("Enter password of user to use in app:");
						String password = sc.next();
						if(!service.validateName(password))
						{
							continue;
						}
						else
						{
							System.out.println("Enter Mobile number of user :");
							String mobile = sc.next();
							if(!service.validatePhone(mobile))
							{
								continue;
							}
							else
							{
								System.out.println("Enter address of user  :");
								String address = sc.next();
								
								if(!service.validateName(address))
								{
									continue;
								}
								else
								{
									System.out.println("Enter balance  of user  :");
									Double balance = sc.nextDouble();
									
						
						if(balance!=null)
						{
							emp = new UserRegister();
							
							
							emp.setName(name);
							emp.setAddress(address);
							emp.setMobile(mobile);
							emp.setUserName(username);
							emp.setPassword(password);
							emp.setBalance(balance);
							
							break;
								}
							}
						}
					}
			
				}
				}
			}
		return emp;

		}
	
	
	}
	

}








