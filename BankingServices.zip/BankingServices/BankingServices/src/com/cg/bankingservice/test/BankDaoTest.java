package com.cg.bankingservice.test;



import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bankingservice.dao.BankDao;
import com.cg.bankingservice.dao.BankDaoImpl;
import com.cg.bankingservice.dto.AdminRegister;
import com.cg.bankingservice.exception.BankException;
import com.cg.bankingservice.service.BankServiceImpl;


public class BankDaoTest {
	
	BankServiceImpl service;
	BankDao dao;
	
	@Before
	public void init()
	{
		dao = new BankDaoImpl();
		service  = new BankServiceImpl();
		service.setDao(dao);
	}
	
	@Test
	public void testAddAdmin() throws BankException
	{
		AdminRegister emp = new AdminRegister();
		emp.setAdminName("kuldeeep");
		emp.setAddress("agra");
		emp.setMobile("7890785643");
		emp.setAdminUserName("kuld");
		emp.setPassword("1234");
		
		int id = service.addAdmin(emp);
		assertNotSame(id,0);
	}
	
	@After
	public void destroy()
	{
		dao = null;
		service = null;
	}

}
