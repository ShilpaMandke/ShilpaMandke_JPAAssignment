package com.cg.bankingservice.exception;

public class BankException extends Exception{
	
	String message;
	
	public BankException(String message)
	{
		this.message = message;
	}
	@Override
	public String getMessage()
	{
		return this.message;
	}

}
