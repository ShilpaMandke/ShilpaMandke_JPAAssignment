package com.cg.bankingservice.dto;

public class UserRegister {

	private int userId;
	private String Name;
	private String UserName;
	private String password;
	private String mobile;
	private String address;
	private double balance;
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public UserRegister(int userId, String name, String userName, String password, String mobile, String address,
			double balance) {
		super();
		this.userId = userId;
		Name = name;
		UserName = userName;
		this.password = password;
		this.mobile = mobile;
		this.address = address;
		this.balance = balance;
	}
	
	public UserRegister() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "UserRegister [userId=" + userId + ", Name=" + Name + ", UserName=" + UserName + ", password=" + password
				+ ", mobile=" + mobile + ", address=" + address + ", balance=" + balance + "]";
	}
	

}
