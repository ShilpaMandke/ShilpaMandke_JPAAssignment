package com.cg.bankingservice.dto;

import java.time.LocalDate;

public class AdminRegister {

	private int adminId;
	private String adminName;
	private String adminUserName;
	private String password;
	private String mobile;
	private String address;
	
	public AdminRegister()
	{
		
	}
	
	
	@Override
	public String toString() {
		return "AdminRegister [adminId=" + adminId + ", adminName=" + adminName + ", adminUserName=" + adminUserName
				+ ", password=" + password + ", mobile=" + mobile + ", address=" + address + "]";
	}


	public AdminRegister(int adminId, String adminName, String adminUserName, String password, String mobile,
			String address) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminUserName = adminUserName;
		this.password = password;
		this.mobile = mobile;
		this.address = address;
	}


	public int getAdminId() {
		return adminId;
	}


	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}


	public String getAdminName() {
		return adminName;
	}


	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}


	public String getAdminUserName() {
		return adminUserName;
	}


	public void setAdminUserName(String adminUserName) {
		this.adminUserName = adminUserName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	
	
	
	
}
