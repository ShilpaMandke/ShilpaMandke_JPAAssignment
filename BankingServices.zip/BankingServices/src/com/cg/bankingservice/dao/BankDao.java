package com.cg.bankingservice.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bankingservice.dto.AdminRegister;
import com.cg.bankingservice.dto.UserRegister;
import com.cg.bankingservice.exception.BankException;




public interface BankDao {

	int addAdmin(AdminRegister emp)throws BankException;
	AdminRegister getAdminById(int adminId)throws BankException;
	int addUser(UserRegister emp)throws BankException;
	UserRegister getUserById(int accountnumber)throws BankException;
	ArrayList<AdminRegister>getAllAdmin()throws BankException;
	ArrayList<UserRegister>getAllUser()throws BankException;
	UserRegister removeUser(int empId)throws BankException;
	AdminRegister removeAdmin(int empId) throws BankException;

}







