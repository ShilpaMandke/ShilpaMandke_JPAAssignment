package com.cg.hotel.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.hotel.dao.HotelDao;
import com.cg.hotel.dao.HotelDaoImpl;
import com.cg.hotel.dto.Hotel;
import com.cg.hotel.exception.CustomerException;

public class HotelServiceImpl implements HotelService {

	
		HotelDao dao;
		
		public void setDao(HotelDao dao)//before set method we need to have ref as above 
		{
			this.dao = dao;
		}
		
		public HotelServiceImpl()
		{
			dao = new HotelDaoImpl();
		}

		@Override
		public int addCustomer(Hotel htl) throws CustomerException {
			// TODO Auto-generated method stub
			return dao.addCustomer(htl);
		}

	/*	@Override
		public Employee removeEmployee(int empId) throws CustomerException {
			// TODO Auto-generated method stub
			return dao.removeEmployee(empId);
		}*/

		@Override
		public Hotel getCustomerById(int htlId) throws CustomerException {
			// TODO Auto-generated method stub
			return dao.getCustomerById(htlId);
		}

		@Override
		public ArrayList<Hotel> getAllCustomer() throws CustomerException {
			// TODO Auto-generated method stub
			return dao.getAllCustomer();
		}

		/*@Override
		public Employee updateEmployee(int empId, int empSal)
				throws CustomerException {
			// TODO Auto-generated method stub
			return dao.updateEmployee(empId, empSal);
		}*/

		@Override
		/*public boolean ValidateEmployee(Employee emp) {
			// TODO Auto-generated method stub
			//return false;
			if (ValidateName(emp.getEmpName()))
					{
				if(ValidateSalary(emp.getEmpSal()))
				{
					return true;
				}
				else
				return false;
				
					}else
						return false;
			
		}*/
		public boolean ValidateName(String name)
		{
			String pattern = "[A-Z]{1}[]a-z]{2,}";
			if(Pattern.matches(pattern, name))
					{
				return true;
				
					}
			else 
				return false;
			
		}
		public boolean ValidatePhone(String phone)
		{
			String pattern ="[0-9]{10,6}";
			String phn =""+phone;
			if(Pattern.matches(pattern,phn))
			{
				return true;
				
			}
			else
				return false;
			
		}
		/*	public boolean ValidateDate(String date)
				{
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate bdate =LocalDate.parse(date,format);
			if(bdate !=null)
			{
				return true;
				
			}
			else
				return false;
			
			
			
				}*/


	}





