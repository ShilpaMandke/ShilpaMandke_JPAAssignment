package com.cg.hotel.dto;

public class User {
	private int id;
	private String password;
	private String role;
	private String user_name;
	private String mobileNo;
	private String phone;
	private String address ;
	private String email;
	
	public User(){}
	public User(int id, String password, String role, String user_name,
			String mobileNo, String phone, String address, String email) {
		super();
		this.id = id;
		this.password = password;
		this.role = role;
		this.user_name = user_name;
		this.mobileNo = mobileNo;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	
	
	
	
	@Override
	public String toString() {
		return "User [id=" + id + ", password=" + password + ", role=" + role
				+ ", user_name=" + user_name + ", mobileNo=" + mobileNo
				+ ", phone=" + phone + ", address=" + address + ", email="
				+ email + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
	
	
	

}


