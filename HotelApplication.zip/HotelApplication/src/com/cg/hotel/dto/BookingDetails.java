package com.cg.hotel.dto;

import java.time.LocalDate;

public class BookingDetails {
private int id;
private int roomId;
private LocalDate BookedFrom;
private LocalDate BookedTo;
private double amount;
@Override
public String toString() {
	return "BookingDetails [id=" + id + ", roomId=" + roomId + ", BookedFrom="
			+ BookedFrom + ", BookedTo=" + BookedTo + ", amount=" + amount
			+ "]";
}

public BookingDetails(){}
public BookingDetails(int id, int roomId, LocalDate bookedFrom,
		LocalDate bookedTo, double amount) {
	super();
	this.id = id;
	this.roomId = roomId;
	BookedFrom = bookedFrom;
	BookedTo = bookedTo;
	this.amount = amount;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getRoomId() {
	return roomId;
}

public void setRoomId(int roomId) {
	this.roomId = roomId;
}

public LocalDate getBookedFrom() {
	return BookedFrom;
}

public void setBookedFrom(LocalDate bookedFrom) {
	BookedFrom = bookedFrom;
}

public LocalDate getBookedTo() {
	return BookedTo;
}

public void setBookedTo(LocalDate bookedTo) {
	BookedTo = bookedTo;
}

public double getAmount() {
	return amount;
}

public void setAmount(double amount) {
	this.amount = amount;
}




}




