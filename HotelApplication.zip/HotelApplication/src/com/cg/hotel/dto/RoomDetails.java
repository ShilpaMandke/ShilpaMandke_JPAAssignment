package com.cg.hotel.dto;

public class RoomDetails {
private int id;
private int roomId;
private int roomNo;
private String roomType;
private double rate;
private boolean availability;

public RoomDetails(){}

public RoomDetails(int id, int roomId, int roomNo, String roomType,
		double rate, boolean availability) {
	super();
	this.id = id;
	this.roomId = roomId;
	this.roomNo = roomNo;
	this.roomType = roomType;
	this.rate = rate;
	this.availability = availability;
}

@Override
public String toString() {
	return "RoomDetails [id=" + id + ", roomId=" + roomId + ", roomNo="
			+ roomNo + ", roomType=" + roomType + ", rate=" + rate
			+ ", availability=" + availability + "]";
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getRoomId() {
	return roomId;
}

public void setRoomId(int roomId) {
	this.roomId = roomId;
}

public int getRoomNo() {
	return roomNo;
}

public void setRoomNo(int roomNo) {
	this.roomNo = roomNo;
}

public String getRoomType() {
	return roomType;
}

public void setRoomType(String roomType) {
	this.roomType = roomType;
}

public double getRate() {
	return rate;
}

public void setRate(double rate) {
	this.rate = rate;
}

public boolean isAvailability() {
	return availability;
}

public void setAvailability(boolean availability) {
	this.availability = availability;
}


  








}

