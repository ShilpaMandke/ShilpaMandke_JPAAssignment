package com.cg.hotel.dao;

import java.util.ArrayList;


import com.cg.hotel.dto.Hotel;
import com.cg.hotel.dto.User;
import com.cg.hotel.exception.CustomerException;


public interface HotelDao {
	int addAdmin(User user)throws CustomerException;
	int addCustomer(Hotel htl)throws CustomerException;
	//Hotel removeCustomer(int htlId)throws CustomerException;
	Hotel getCustomerById(int htlId)throws CustomerException;
	ArrayList<User>getAllAdmin()throws CustomerException;
	ArrayList<Hotel>getAllCustomer()throws CustomerException;
	//Hotel updateCustomer(int empId,int empSal)throws CustomerException;
}
