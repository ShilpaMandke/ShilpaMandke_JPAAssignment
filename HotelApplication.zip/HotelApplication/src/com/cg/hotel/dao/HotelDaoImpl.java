package com.cg.hotel.dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;




import com.cg.hotel.dto.Hotel;
import com.cg.hotel.dto.User;
import com.cg.hotel.exception.CustomerException;
import com.cg.hotel.util.DBUtil;
import com.cg.logger.MyLoger;

public class HotelDaoImpl implements HotelDao{
	

	
	
	 
		
		Connection con;
		Logger logger;
		
		public HotelDaoImpl()
		{
			con = DBUtil.getConnect();
			logger= MyLoger.getLogger();
		}

		public int getHotelId()throws CustomerException
		{
			logger.info("In getHotelId");
			int id = 0;
			String qry = "SELECT seq_hotel_id.CURRVAL FROM DUAL";
				try{
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(qry);
				if(rs.next())
				{
					id = rs.getInt(1);
					logger.info("Get Hotel with id"+id);
				}
				}
				catch(SQLException e)
				{logger.error("error "+e.getMessage());
					throw new CustomerException(e.getMessage());
				}
				logger.info("Completed getHotelId");
						return id;
				
		}
		
		
		
		public int addAdmin(User user) throws CustomerException {
			// TODO Auto-generated method stub
			logger.info("In Add user");
			logger.info("Input is "+user);
			int id = 0;
			String qry = "INSERT INTO user VALUES(userId_seq.NEXTVAL,?,?,?,?,?,?,?)";
			String username = user.getUser_name();
			String pass = user.getPassword();
			String role = user.getRole(); 
			
			String mobile = user.getMobileNo();
			String phone = user.getPhone();
			
			String email = user.getEmail();
			String address = user.getAddress();
			
			try
			{
				PreparedStatement pstmt = 
						con.prepareStatement(qry);
				pstmt.setString(1, username);
				pstmt.setString(2, pass);
				pstmt.setString(3, role);
				pstmt.setString(4, mobile);
				pstmt.setString(5, phone);
				pstmt.setString(6, email);
				pstmt.setString(7, address);
				
				
				
				int row = pstmt.executeUpdate();
				if(row > 0)
				{
					id = getHotelId();
					logger.info("Inserted successfully and Id is = "+id);
				}
				else
					throw new CustomerException("unable to insert"+user);
				
			}
			catch(SQLException e)
			{
				logger.error("Error in insert = "+e.getMessage());
				throw new CustomerException(e.getMessage());
			}
			return id;
			
			
			
			
			
		}
		@Override
		public int addCustomer(Hotel htl) throws CustomerException {
			// TODO Auto-generated method stub
			logger.info("In Add Customer");
			logger.info("Input is"+htl);
			int id = 0;
			String qry = "INSERT INTO hotel VALUES(seq_hotel_id.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";
			String city = htl.getCity();
			String name = htl.getName();
			String address = htl.getAddress();
			String description = htl.getDescription();
			double rate =htl.getRate();
			String phoneNo1=htl.getPhoneNo1();
			String phoneNo2=htl.getPhoneNo1();
			String rating = htl.getRating();
			String email=htl.getEmail();
			Long fax=htl.getFax();
			
			try
			{
				PreparedStatement pstmt = 
						con.prepareStatement(qry);
				pstmt.setString(1, city);
				pstmt.setString(2, name);
				pstmt.setString(3, address);
				pstmt.setString(4, description);
				pstmt.setDouble(5,rate);
				pstmt.setString(6,phoneNo1);
				pstmt.setString(7,phoneNo2);
				pstmt.setString(8, rating);
				pstmt.setString(9, email);
				pstmt.setLong(10, fax);
				int row = pstmt.executeUpdate();
				if(row > 0)
				{
					id = getHotelId();
					logger.info("inserted successfully and id is  "+id);
				}
				else
					throw new CustomerException("unable to insert"+htl);
				
			}
			catch(SQLException e)
			{logger.error("error in insert ="+e.getMessage());
				throw new CustomerException(e.getMessage());
			}
			return id;
		}

		/*@Override
		public Employee removeEmployee(int empId) throws CustomerException {
			// TODO Auto-generated method stub
			Employee emp = null;
			String qry = "DELETE FROM EmployeeJEE WHERE empId=?";
			try
			{
				PreparedStatement pstmt = 
						con.prepareStatement(qry);
				pstmt.setInt(1, empId);
				emp = getEmployeeById(empId);
				int row = pstmt.executeUpdate();
				if(emp==null)
				{
					throw new CustomerException("emp with id "+empId+"not found");
				}
				else if(row > 0)
				{
					System.out.println("Deleted Employee with Id "+empId);
					
				}
				
			}
			catch(SQLException e)
			{
				throw new CustomerException(e.getMessage());
			}
			return emp;
		}*/

		@Override
		public Hotel getCustomerById(int htlId) throws CustomerException {
			// TODO Auto-generated method stub
			Hotel htl = null;
			String qry = "SELECT * FROM Hotel WHERE hotel_id=?";
			try
			{
				PreparedStatement pstmt = con.prepareStatement(qry);
				pstmt.setInt(1, htlId);
				ResultSet rs = pstmt.executeQuery();
				if(rs.next())
				{
					int id = rs.getInt(1);
					String city = rs.getString(2);
					String name = rs.getString(3);
					String address = rs.getString(4);
					String description = rs.getString(5);
					double rate =rs.getDouble(6);
					String phoneNo1= rs.getString(7);
					String phoneNo2= rs.getString(8);
					String rating = rs.getString(9);
					String email = rs.getString(10);
					Long fax =rs.getLong(11);
					htl = new Hotel(id,city,name,address,description,rate,phoneNo1,phoneNo2,rating,email,fax);
				}
				else
					throw new CustomerException("Hotel with id "+htlId+"not found");
			}
			catch(SQLException e)
			{
				throw new CustomerException(e.getMessage());
			}
			return htl;
		}

		@Override
		public ArrayList<Hotel> getAllCustomer() throws CustomerException {
			// TODO Auto-generated method stub
			ArrayList<Hotel> list = new ArrayList<Hotel>();
			String qry = "SELECT * FROM hotel";
			try
			{
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(qry);
				while(rs.next())
				{
					int id = rs.getInt(1);
					String city = rs.getString(2);
					String name = rs.getString(3);
					String address = rs.getString(4);
					String description = rs.getString(5);
					double rate =rs.getDouble(6);
					String phoneNo1= rs.getString(7);
					String phoneNo2= rs.getString(8);
					String rating = rs.getString(9);
					String email = rs.getString(10);
					Long fax =rs.getLong(11);
					Hotel htl = new Hotel(id,city,name,address,description,rate,phoneNo1,phoneNo2,rating,email,fax);
					list.add(htl);
				}
			}
			catch(SQLException e)
			{
				throw new CustomerException(e.getMessage());
			}
			return list;
		}

		@Override
		public ArrayList<User> getAllAdmin() throws CustomerException {
			// TODO Auto-generated method stub
			
				ArrayList<User>list = new ArrayList<User>();
				String qry = "SELECT * FROM user";
				try
				{
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery(qry);
					while(rs.next())
					{	
					int id = rs.getInt(1);
					String username =rs.getString(2);
					String pass = rs.getString(3);
					String role = rs.getString(4);
					
					String mobile = rs.getString(5);
					String phone = rs.getString(6);
					
					String email = rs.getString(7);
					String address = rs.getString(8);
						
						
						User user = new User(id,username,pass,role,mobile,phone,email,address);
						list.add(user);
					}
				}
				catch(SQLException e)
				{
					throw new CustomerException(e.getMessage());
				}
				return list;
			}
		}

		/*@Override
		public Employee updateEmployee(int empId, int empSal)
				throws CustomerException {
			// TODO Auto-generated method stub
			Employee emp = getEmployeeById(empId);
			if(emp==null)
				throw new CustomerException("Employee with id "+empId+"Not found");
			else
			{
				String qry = "UPDATE EmployeeJEE SET empSal=? WHERE empId=?";
				try{
					PreparedStatement pstmt = 
							con.prepareStatement(qry);
					pstmt.setInt(1, emp.getEmpSal()+empSal);
					pstmt.setInt(2, empId);
					int row = pstmt.executeUpdate();
					if(row > 0)
					{
						System.out.println("updated successfully");
						emp = getEmployeeById(empId);
					}      
				}
				catch(SQLException e)
				{
					throw new CustomerException(e.getMessage());
				}
				
			}
			return emp;
		}*/

	







