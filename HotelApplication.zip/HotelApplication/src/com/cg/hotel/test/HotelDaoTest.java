package com.cg.hotel.test;



import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.hotel.dao.HotelDao;
import com.cg.hotel.dao.HotelDaoImpl;
import com.cg.hotel.dto.Hotel;
import com.cg.hotel.exception.CustomerException;
import com.cg.hotel.service.HotelServiceImpl;


public class HotelDaoTest {
	HotelServiceImpl service;
	HotelDao dao; //=new EmployeeDaoImpl();
	
	
	@Before
	public  void init()
	{
		dao= new HotelDaoImpl();
		service = new HotelServiceImpl();
		service.setDao(dao);
	}
	@Test
	public void testGetAllCustomer()throws CustomerException
	{
		ArrayList<Hotel> list = service.getAllCustomer();
		
		assertNotNull(list);
	}
	@Test
	public void testAddCustomer() throws CustomerException
	{
		Hotel htl = new Hotel();
		
		htl.setCity("Mumbai");
		htl.setName("Oberoi");
		htl.setAddress("nariman point");
	htl.setDescription("Best Services");
	htl.setRate(2500.00);
	htl.setPhoneNo1("9820778548");
	htl.setPhoneNo2("8898118385");
	htl.setRating("5 Star");
	htl.setEmail("shilpa@gmail.com");
	htl.setFax(87520);
		int id = service.addCustomer(htl);
		assertNotSame(id,0);
	}
	/*public void testDeleteEmployee() throws CustomerException
	{
		Hotel emp = service.removeCustomer(2000);
		assertNotNull(emp);
		
	}*/
	/*public void updateEmployee() throws CustomerException
	{
		Hotel emp = service.updateEmployee(2002,20000);
		assertNotNull(emp);
		
	}*/
	@After
	public void destroy()
	{
		dao = null;
		service= null;
	}

}
