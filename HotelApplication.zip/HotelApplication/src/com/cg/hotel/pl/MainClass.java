package com.cg.hotel.pl;

import java.util.ArrayList;
import java.util.Scanner;



import com.cg.hotel.service.HotelService;
import com.cg.hotel.service.HotelServiceImpl;

public class MainClass {
	static HotelService service = new HotelServiceImpl();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice = 0;
		try(Scanner sc = new Scanner(System.in))
		{
			do
			{
				System.out.println("1-Add Customer");
				System.out.println("2-Search By Id");
				System.out.println("3-Search All");
				
				System.out.println("Enter choice::");
				choice = sc.nextInt();
				switch(choice)
				{
					case 1 : 
						
						Hotel htl = acceptCustomerDetails(); 
					if(htl!=null){	
					try
					{
						int id = service.addCustomer(htl);
						System.out.println("inserted and id = "+id);
					}
					catch(CustomerException e)
					{
						System.out.println(e.getMessage());
					}}
					break;
					
					
					case 2 : System.out.println("Enter id to search Cust::");
					int eid = sc.nextInt();
					try
					{
						Hotel ref = service.getCustomerById(eid);
						System.out.println("emp "+ref);
					}
					catch(CustomerException e)
					{
						System.out.println(e.getMessage());
					}
					break;
					
					case 4 : 
						try{ArrayList<Employee>list = 
						service.getAllEmployee();
						for(Employee obj : list)
						{
							System.out.println(obj);
						}
						}
						catch(CustomerException e)
						{
							System.out.println(e.getMessage());
						}
						break;

}
}
		
